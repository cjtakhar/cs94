﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HW2NoteKeeper.Migrations
{
    /// <inheritdoc />
    public partial class FixTagCascadeDelete : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Tag_Note_NoteId1",
                table: "Tag");

            migrationBuilder.DropIndex(
                name: "IX_Tag_NoteId1",
                table: "Tag");

            migrationBuilder.DropColumn(
                name: "NoteId1",
                table: "Tag");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "NoteId1",
                table: "Tag",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Tag_NoteId1",
                table: "Tag",
                column: "NoteId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Tag_Note_NoteId1",
                table: "Tag",
                column: "NoteId1",
                principalTable: "Note",
                principalColumn: "NoteId");
        }
    }
}
